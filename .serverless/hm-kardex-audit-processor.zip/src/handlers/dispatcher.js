"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/handlers/dispatcher.ts
var dispatcher_exports = {};
__export(dispatcher_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(dispatcher_exports);
var import_client_sfn = require("@aws-sdk/client-sfn");
var client = new import_client_sfn.SFNClient({ region: process.env.AWS_REGION });
var handler = async (event) => {
  console.log("RAW EVENT", event);
  const payload = event.Records && event.Records.length > 0 ? JSON.parse(event.Records[0].body) : typeof event === "string" ? JSON.parse(event) : event;
  console.log("PAYLOAD", payload);
  const auditJobId = payload.auditJobId;
  if (!auditJobId) {
    throw new Error("auditJobId is required");
  }
  const execution = await client.send(
    new import_client_sfn.StartExecutionCommand({
      stateMachineArn: process.env.STATE_MACHINE_ARN,
      input: JSON.stringify({ auditJobId })
    })
  );
  console.log("Execution Started:", execution.executionArn);
  return {
    ok: true,
    executionArn: execution.executionArn
  };
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
//# sourceMappingURL=dispatcher.js.map
