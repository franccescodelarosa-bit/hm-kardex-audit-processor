"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/handlers/download-files.ts
var download_files_exports = {};
__export(download_files_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(download_files_exports);
var import_fs2 = __toESM(require("fs"));

// src/services/s3.service.ts
var import_client_s3 = require("@aws-sdk/client-s3");
var import_fs = require("fs");
var import_promises = require("stream/promises");
var import_path = __toESM(require("path"));
var s3 = new import_client_s3.S3Client({ region: process.env.AWS_REGION || "us-east-1" });
var S3Service = class {
  static async download(file) {
    console.log(`\u2B07 Downloading ${file.file_name}`);
    const command = new import_client_s3.GetObjectCommand({
      Bucket: process.env.S3_BUCKET,
      Key: file.s3_key
    });
    const response = await s3.send(command);
    if (!response.Body) {
      throw new Error(`Empty body for ${file.file_name}`);
    }
    const localPath = import_path.default.join("/tmp", file.file_name);
    await (0, import_promises.pipeline)(
      response.Body,
      (0, import_fs.createWriteStream)(localPath)
    );
    console.log(`\u2705 Downloaded ${file.file_name}`);
    return localPath;
  }
};

// src/handlers/download-files.ts
var handler = async (event) => {
  console.log("DOWNLOAD FILES");
  console.log(JSON.stringify(event, null, 2));
  const files = event.files;
  if (!files || files.length === 0) {
    throw new Error("No files found.");
  }
  const localFiles = await S3Service.download(files);
  console.log("========== TMP ==========");
  console.log(import_fs2.default.readdirSync("/tmp"));
  console.log("=========================");
  return {
    ...event,
    localFiles
  };
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
//# sourceMappingURL=download-files.js.map
