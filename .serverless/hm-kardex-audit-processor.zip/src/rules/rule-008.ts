import { AuditData } from "../models/audit-data";
import { Finding } from "../models/finding";
import { CodeHelper } from "../helpers/code.helper";
import { DateHelper } from "../helpers/date.helper";
export class Rule008 {
    static execute(data: AuditData): Finding[] {
        const findings: Finding[] = [];
        // Maestro construido con Inventario Inicial + Inventario Final
        const masterCodes = new Set<string>();
        for (const item of data.initialInventory) {
            masterCodes.add(CodeHelper.normalize(item.code));
        }
        for (const item of data.finalInventory) {
            masterCodes.add(CodeHelper.normalize(item.code));
        }

        const kardexCodes = new Set<string>();
        for (const product of data.kardex) {
            kardexCodes.add(CodeHelper.normalize(product.code));
        }

        this.validateKardex(
            data.kardex,
            findings,
            masterCodes
        );

        this.validateInventory(
            data.initialInventory,
            "INVENTARIO_INICIAL",
            findings,
            kardexCodes
        );
        this.validateInventory(
            data.finalInventory,
            "INVENTARIO_FINAL",
            findings,
            kardexCodes
        );

        return findings;
    }

    private static validateInventory(
        inventory: { code: string; product: string }[],
        source: string,
        findings: Finding[],
        kardexCodes: Set<string>
    ) {
        const processed = new Set<string>();
        for (const item of inventory) {
            const code = CodeHelper.normalize(item.code);
            if (processed.has(code)) {
                continue;
            }
            processed.add(code);
            if (kardexCodes.has(code)) {
                continue;
            }
            findings.push({
                ruleId: "RULE_008",
                productCode: item.code,
                productName: item.product,
                errorType: "INVENTORY_CODE_NOT_IN_KARDEX",
                description:
                    `El producto existe en el ${source === "INVENTARIO_INICIAL" ? "Inventario Inicial" : "Inventario Final"} ` +
                    "pero no aparece en el Kardex.",
                recommendation:
                    "Verifique el código del producto o confirme que tenga movimientos registrados en el Kardex.",
                riskLevel: "ALTO",
                metadata: {
                    source
                }
            });
        }
    }

    private static validateKardex(
        products: any[],
        findings: Finding[],
        masterCodes: Set<string>
    ) {
        const processed = new Set<string>();
        for (const product of products) {
            const code = CodeHelper.normalize(product.code);
            if (processed.has(code)) {
                continue;
            }
            processed.add(code);
            if (masterCodes.has(code)) {
                continue;
            }
            const balance = product.movements.at(-1)?.balanceQuantity ?? 0;
            if (balance === 0) {
                continue;
            }
            const firstMovement = product.movements.find(
                (m : any) => !m.document?.startsWith("00 Saldo Inicial")
            );

            const reference = firstMovement ?? product.movements[0];
            findings.push({
                ruleId: "RULE_008",
                productCode: product.code,
                productName: product.product ?? product.description,
                errorType: "MASTER_CODE_NOT_FOUND",
                description:
                    "El producto existe en el Kardex pero no aparece ni en el Inventario Inicial ni en el Inventario Final.",
                recommendation:
                    "Verifique el código del producto o confirme que forme parte del catálogo de inventarios.",
                riskLevel: "ALTO",
                metadata: {
                    source: "KARDEX",
                    month: reference.month,
                    date: DateHelper.toDateString(reference.date),
                    document: reference.document
                }
            });
        }
    }
}